Udacity Robotic Software Engineering Course- home robot that can navigate in a given environment, finding objects and depositing them at a given location. Created and performed in gazebo. Involves gazebo basics, localisation, simultaneous localisation and mapping (SLAM), and path planning and navigation.

Instructions: On a linux pc...

Create "catkin_ws" directory
Create a directory "src" within this
Clone homeRobot into src
Initialise catkin workspace with $ catkin_init_workspace
In catkin_ws, compile files with $ catkin_make Other files should generate as a result
$ source devel/setup.bash
Now launch/run any files as needed
Project 2 - Go Chase It! ***

In terminal 1:

$ cd /home/workspace/catkin_ws/ $ source devel/setup.bash $ roslaunch my_robot world.launch

In terminal 2:

$ cd /home/workspace/catkin_ws/ $ source devel/setup.bash $ roslaunch ball_chaser ball_chaser.launch

In terminal 3:

$ cd /home/workspace/catkin_ws/ $ source devel/setup.bash $ rosrun rqt_image_view rqt_image_view